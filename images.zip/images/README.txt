Lean Bite meal images

Put the 40 meal images in this folder.

Recommended filenames:
meal-01.jpg
meal-02.jpg
...
meal-40.jpg

You can also use .png or .webp, but keep the HTML image paths consistent.
